import sys
import unittest
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]
PACKAGE_PARENT = REPO_ROOT.parent

if str(PACKAGE_PARENT) not in sys.path:
    sys.path.insert(0, str(PACKAGE_PARENT))

import MKRShift_Nodes as pack  # noqa: E402


class NodePackSmokeTests(unittest.TestCase):
    def test_registry_and_display_names_stay_in_sync(self) -> None:
        node_keys = set(pack.NODE_CLASS_MAPPINGS)
        display_keys = set(pack.NODE_DISPLAY_NAME_MAPPINGS)

        self.assertGreaterEqual(len(node_keys), 100)
        self.assertEqual(node_keys, display_keys)

    def test_web_directory_exists(self) -> None:
        web_dir = (REPO_ROOT / pack.WEB_DIRECTORY).resolve()
        self.assertTrue(web_dir.is_dir(), f"Missing web directory: {web_dir}")

    def test_v3_entrypoint_is_exposed(self) -> None:
        self.assertTrue(callable(getattr(pack, "comfy_entrypoint", None)))

    def test_nodes_expose_required_comfy_metadata(self) -> None:
        for name, cls in pack.NODE_CLASS_MAPPINGS.items():
            with self.subTest(node=name):
                self.assertTrue(callable(getattr(cls, "INPUT_TYPES", None)))

                input_types = cls.INPUT_TYPES()
                self.assertIsInstance(input_types, dict)
                self.assertTrue(
                    any(section in input_types for section in ("required", "optional", "hidden")),
                    "INPUT_TYPES should expose at least one input section",
                )

                category = getattr(cls, "CATEGORY", "")
                self.assertIsInstance(category, str)
                self.assertTrue(category.strip())

                function_name = getattr(cls, "FUNCTION", "")
                self.assertIsInstance(function_name, str)
                self.assertTrue(function_name.strip())
                self.assertTrue(callable(getattr(cls, function_name, None)))

                return_types = getattr(cls, "RETURN_TYPES", ())
                self.assertIsInstance(return_types, tuple)
                if len(return_types) == 0:
                    self.assertTrue(bool(getattr(cls, "OUTPUT_NODE", False)))
                else:
                    self.assertGreater(len(return_types), 0)

                display_name = pack.NODE_DISPLAY_NAME_MAPPINGS.get(name, "")
                self.assertIsInstance(display_name, str)
                self.assertTrue(display_name.strip())

    def test_surface_expansion_nodes_are_registered(self) -> None:
        expected = {
            "MKRCharacterState",
            "MKROutfitSet",
            "MKRCLIPTextEncodePrompt",
            "MKRAddonWorkflowInterface",
            "MKRJSONDiff",
            "MKRAddonStats",
            "MKRBlenderSceneImport",
            "MKRBlenderCameraShot",
            "MKRBlenderImageImport",
            "MKRBlenderImageOutputPlan",
            "MKRBlenderImageOutput",
            "MKRBlenderMaterialImport",
            "MKRBlenderMaterialReturnPlan",
            "MKRBlenderReturnPlan",
            "MKRBlenderReturnOutput",
            "MKRTouchDesignerImport",
            "MKRTouchDesignerFramePlan",
            "MKRTiXLImport",
            "MKRTiXLFramePlan",
            "MKROSCMessagePlan",
            "MKRAddonEndpointPlan",
            "MKRNDIStreamPlan",
            "MKRSpoutSenderPlan",
            "MKRSyphonSenderPlan",
            "MKRTCPBridgePlan",
            "MKRHTTPWebhookPlan",
            "MKRWatchFolderPlan",
            "MKRWebSocketBridgePlan",
            "MKRAddonEndpointSubmit",
            "MKRAddonEndpointPoll",
            "MKRHTTPWebhookSend",
            "MKRTCPBridgeSend",
            "MKROSCSend",
            "MKRWatchFolderWrite",
            "MKRNukeScriptImport",
            "MKRNukeReadPlan",
            "MKRNukeReadOutput",
            "MKRNukeImageImport",
            "MKRNukeImageOutputPlan",
            "MKRNukeImageOutput",
            "MKRPhotoshopDocumentImport",
            "MKRPhotoshopExportPlan",
            "MKRPhotoshopExportOutput",
            "MKRPhotoshopImageImport",
            "MKRPhotoshopImageOutputPlan",
            "MKRPhotoshopImageOutput",
            "MKRAfterEffectsCompImport",
            "MKRAfterEffectsRenderPlan",
            "MKRAfterEffectsRenderOutput",
            "MKRAfterEffectsImageImport",
            "MKRAfterEffectsImageOutputPlan",
            "MKRAfterEffectsImageOutput",
            "MKRPremiereSequenceImport",
            "MKRPremiereExportPlan",
            "MKRPremiereExportOutput",
            "MKRPremiereImageImport",
            "MKRPremiereImageOutputPlan",
            "MKRPremiereImageOutput",
            "MKRAffinityDocumentImport",
            "MKRAffinityExportPlan",
            "MKRAffinityExportOutput",
            "MKRAffinityPhotoshopPluginPlan",
            "MKRFusion360SceneImport",
            "MKRFusion360TexturePlan",
            "MKRFusion360TextureOutput",
            "MKRFusion360ImageImport",
            "MKRFusion360ImageOutputPlan",
            "MKRFusion360ImageOutput",
            "MKRMayaSceneImport",
            "MKRMayaMaterialPlan",
            "MKRMayaMaterialOutput",
            "MKRMayaImageImport",
            "MKRMayaImageOutputPlan",
            "MKRMayaImageOutput",
            "MKRPoseStudio",
            "x1ClearcoatMap",
            "x1ClearcoatRoughnessMap",
            "x1SheenMap",
            "x1TransmissionMap",
            "x1ThicknessMap",
            "x1IridescenceMap",
            "x1ScalarMapAdjust",
            "x1ColorRegionMask",
            "x1EdgeWearMask",
            "x1AnisotropyMap",
            "x1TextureAlbedoSafe",
            "x1TextureMacroVariation",
            "x1TextureDetileBlend",
            "x1TextureNoiseField",
            "x1TextureCellPattern",
            "x1TextureHexTiles",
            "x1TextureStrata",
            "x1TextureWeavePattern",
            "MKRStudioSelectionSet",
            "MKRStudioReviewNotes",
            "MKRStudioDeliverySheet",
            "MKRPublishPromoFrame",
            "MKRPublishEndCard",
            "MKRPublishAssetManifest",
            "MKRPublishManifestAtIndex",
            "MKRPublishCopyDeck",
            "MKRPublishCopyAtIndex",
            "MKRBatchDifferencePreview",
            "x1LightWrapComposite",
            "x1EdgeAberration",
            "MKRLayerStackComposite",
        }
        self.assertTrue(expected.issubset(set(pack.NODE_CLASS_MAPPINGS)))


if __name__ == "__main__":
    unittest.main()
