# MKRShift Nodes Wiki

Welcome to the MKRShift Nodes wiki.

This wiki is organized to match the current pack taxonomy so the GitHub wiki stays aligned with the node menu inside ComfyUI.

## Getting Started

- [Repository README](../../README.md)
- [MKRPreSave](MKRPreSave.md)
- [MKRPresaveVideo](MKRPresaveVideo.md)
- [MKRPresaveAudio](MKRPresaveAudio.md)

## Direction + Layout

- [MKRCharacterCustomizer](MKRCharacterCustomizer.md)
- [MKRCharacterState](MKRCharacterState.md)
- [MKROutfitSet](MKROutfitSet.md)
- [MKRPoseStudio](MKRPoseStudio.md)
- [MKRCLIPTextEncodePrompt](MKRCLIPTextEncodePrompt.md)
- [AngleShift](AngleShift.md)
- [Aspect1X](Aspect1X.md)
- [Aspect1XBatch](Aspect1XBatch.md)
- [AxBCompare](AxBCompare.md)
- [MKRAddonWorkflowInterface](MKRAddonWorkflowInterface.md)
- [MKRJSONDiff](MKRJSONDiff.md)
- [MKRAddonStats](MKRAddonStats.md)

## Layer + Composite

- [MKRLayerStackComposite](MKRLayerStackComposite.md)

## Blender Bridge

- [MKRBlenderSceneImport](MKRBlenderSceneImport.md)
- [MKRBlenderCameraShot](MKRBlenderCameraShot.md)
- [MKRBlenderImageImport](MKRBlenderImageImport.md)
- [MKRBlenderImageOutputPlan](MKRBlenderImageOutputPlan.md)
- [MKRBlenderImageOutput](MKRBlenderImageOutput.md)
- [MKRBlenderMaterialImport](MKRBlenderMaterialImport.md)
- [MKRBlenderMaterialReturnPlan](MKRBlenderMaterialReturnPlan.md)
- [MKRBlenderReturnPlan](MKRBlenderReturnPlan.md)
- [MKRBlenderReturnOutput](MKRBlenderReturnOutput.md)

## TouchDesigner Bridge

- [MKRTouchDesignerImport](MKRTouchDesignerImport.md)
- [MKRTouchDesignerFramePlan](MKRTouchDesignerFramePlan.md)

## TiXL Bridge

- [MKRTiXLImport](MKRTiXLImport.md)
- [MKRTiXLFramePlan](MKRTiXLFramePlan.md)

## Network Addon

- [MKRAddonEndpointPlan](MKRAddonEndpointPlan.md)
- [MKROSCMessagePlan](MKROSCMessagePlan.md)
- [MKRNDIStreamPlan](MKRNDIStreamPlan.md)
- [MKRSpoutSenderPlan](MKRSpoutSenderPlan.md)
- [MKRSyphonSenderPlan](MKRSyphonSenderPlan.md)
- [MKRTCPBridgePlan](MKRTCPBridgePlan.md)
- [MKRHTTPWebhookPlan](MKRHTTPWebhookPlan.md)
- [MKRWatchFolderPlan](MKRWatchFolderPlan.md)
- [MKRWebSocketBridgePlan](MKRWebSocketBridgePlan.md)
- [MKRAddonEndpointSubmit](MKRAddonEndpointSubmit.md)
- [MKRAddonEndpointPoll](MKRAddonEndpointPoll.md)
- [MKRHTTPWebhookSend](MKRHTTPWebhookSend.md)
- [MKRTCPBridgeSend](MKRTCPBridgeSend.md)
- [MKROSCSend](MKROSCSend.md)
- [MKRWatchFolderWrite](MKRWatchFolderWrite.md)

## Nuke Addon

- [MKRNukeScriptImport](MKRNukeScriptImport.md)
- [MKRNukeReadPlan](MKRNukeReadPlan.md)
- [MKRNukeReadOutput](MKRNukeReadOutput.md)
- [MKRNukeImageImport](MKRNukeImageImport.md)
- [MKRNukeImageOutputPlan](MKRNukeImageOutputPlan.md)
- [MKRNukeImageOutput](MKRNukeImageOutput.md)

## Photoshop Addon

- [MKRPhotoshopDocumentImport](MKRPhotoshopDocumentImport.md)
- [MKRPhotoshopExportPlan](MKRPhotoshopExportPlan.md)
- [MKRPhotoshopExportOutput](MKRPhotoshopExportOutput.md)
- [MKRPhotoshopImageImport](MKRPhotoshopImageImport.md)
- [MKRPhotoshopImageOutputPlan](MKRPhotoshopImageOutputPlan.md)
- [MKRPhotoshopImageOutput](MKRPhotoshopImageOutput.md)

## After Effects Addon

- [MKRAfterEffectsCompImport](MKRAfterEffectsCompImport.md)
- [MKRAfterEffectsRenderPlan](MKRAfterEffectsRenderPlan.md)
- [MKRAfterEffectsRenderOutput](MKRAfterEffectsRenderOutput.md)
- [MKRAfterEffectsImageImport](MKRAfterEffectsImageImport.md)
- [MKRAfterEffectsImageOutputPlan](MKRAfterEffectsImageOutputPlan.md)
- [MKRAfterEffectsImageOutput](MKRAfterEffectsImageOutput.md)

## Premiere Pro Addon

- [MKRPremiereSequenceImport](MKRPremiereSequenceImport.md)
- [MKRPremiereExportPlan](MKRPremiereExportPlan.md)
- [MKRPremiereExportOutput](MKRPremiereExportOutput.md)
- [MKRPremiereImageImport](MKRPremiereImageImport.md)
- [MKRPremiereImageOutputPlan](MKRPremiereImageOutputPlan.md)
- [MKRPremiereImageOutput](MKRPremiereImageOutput.md)

## Affinity Addon

- [MKRAffinityDocumentImport](MKRAffinityDocumentImport.md)
- [MKRAffinityExportPlan](MKRAffinityExportPlan.md)
- [MKRAffinityExportOutput](MKRAffinityExportOutput.md)
- [MKRAffinityPhotoshopPluginPlan](MKRAffinityPhotoshopPluginPlan.md)

## Fusion 360 Addon

- [MKRFusion360SceneImport](MKRFusion360SceneImport.md)
- [MKRFusion360TexturePlan](MKRFusion360TexturePlan.md)
- [MKRFusion360TextureOutput](MKRFusion360TextureOutput.md)
- [MKRFusion360ImageImport](MKRFusion360ImageImport.md)
- [MKRFusion360ImageOutputPlan](MKRFusion360ImageOutputPlan.md)
- [MKRFusion360ImageOutput](MKRFusion360ImageOutput.md)

## Maya Addon

- [MKRMayaSceneImport](MKRMayaSceneImport.md)
- [MKRMayaMaterialPlan](MKRMayaMaterialPlan.md)
- [MKRMayaMaterialOutput](MKRMayaMaterialOutput.md)
- [MKRMayaImageImport](MKRMayaImageImport.md)
- [MKRMayaImageOutputPlan](MKRMayaImageOutputPlan.md)
- [MKRMayaImageOutput](MKRMayaImageOutput.md)

## Inspect + Preview

- [MKRBatchCollagePreview](MKRBatchCollagePreview.md)
- [MKRBatchDifferencePreview](MKRBatchDifferencePreview.md)

## Color / Lookdev

- [xLUT](xLUT.md)
- [xLUTOutput](xLUTOutput.md)

## Mask + Utility

- [x1MaskGen](x1MaskGen.md)

## Surface / Preview + Packing

- [x1PreviewMaterial](x1PreviewMaterial.md)
- [x1PBRPack](x1PBRPack.md)

## Surface / Maps

- [x1Heightmap](x1Heightmap.md)
- [x1RoughnessMap](x1RoughnessMap.md)
- [x1SpecularMap](x1SpecularMap.md)
- [x1MetalnessMap](x1MetalnessMap.md)
- [x1OpacityMap](x1OpacityMap.md)
- [x1ClearcoatMap](x1ClearcoatMap.md)
- [x1ClearcoatRoughnessMap](x1ClearcoatRoughnessMap.md)
- [x1SheenMap](x1SheenMap.md)
- [x1TransmissionMap](x1TransmissionMap.md)
- [x1ThicknessMap](x1ThicknessMap.md)
- [x1IridescenceMap](x1IridescenceMap.md)
- [x1EmissiveMap](x1EmissiveMap.md)
- [x1CavityMap](x1CavityMap.md)
- [x1AnisotropyMap](x1AnisotropyMap.md)
- [x1ColorRegionMask](x1ColorRegionMask.md)
- [x1EdgeWearMask](x1EdgeWearMask.md)
- [x1ScalarMapAdjust](x1ScalarMapAdjust.md)
- [x1NormalMap](x1NormalMap.md)

## Surface / Texture

- [x1TextureDelight](x1TextureDelight.md)
- [x1TextureAlbedoSafe](x1TextureAlbedoSafe.md)
- [x1TextureDetileBlend](x1TextureDetileBlend.md)
- [x1TextureMacroVariation](x1TextureMacroVariation.md)
- [x1TextureNoiseField](x1TextureNoiseField.md)
- [x1TextureCellPattern](x1TextureCellPattern.md)
- [x1TextureHexTiles](x1TextureHexTiles.md)
- [x1TextureStrata](x1TextureStrata.md)
- [x1TextureWeavePattern](x1TextureWeavePattern.md)
- [x1TextureOffset](x1TextureOffset.md)
- [x1TextureSeamless](x1TextureSeamless.md)
- [x1TextureTilePreview](x1TextureTilePreview.md)
- [x1TextureEdgePad](x1TextureEdgePad.md)

## Surface / Tech Art

- [x1ChannelBreakout](x1ChannelBreakout.md)
- [x1ChannelPack](x1ChannelPack.md)
- [x1CurvatureFromNormal](x1CurvatureFromNormal.md)
- [x1NormalBlend](x1NormalBlend.md)
- [x1UVCheckerOverlay](x1UVCheckerOverlay.md)
- [x1SlopeMaskFromNormal](x1SlopeMaskFromNormal.md)
- [x1AOFromHeight](x1AOFromHeight.md)
- [x1IDMapQuantize](x1IDMapQuantize.md)
- [x1IDMaskExtract](x1IDMaskExtract.md)
- [x1NormalTweak](x1NormalTweak.md)

## VFX / Optics / Finishing

- [x1AnamorphicStreaks](x1AnamorphicStreaks.md)
- [x1HeatHaze](x1HeatHaze.md)
- [x1LensDirtBloom](x1LensDirtBloom.md)
- [x1LightWrapComposite](x1LightWrapComposite.md)
- [x1EdgeAberration](x1EdgeAberration.md)
- [x1Heatmap](x1Heatmap.md)

## Face Performance

- [MKRFacePerformanceRigBuildNeutral](MKRFacePerformanceRigBuildNeutral.md)
- [MKRFacePerformanceRigApplyDeltas](MKRFacePerformanceRigApplyDeltas.md)
- [MKRFacePerformanceEyeMotion](MKRFacePerformanceEyeMotion.md)
- [MKRFacePerformanceLipRefine](MKRFacePerformanceLipRefine.md)
- [MKRFacePerformancePoseMerge](MKRFacePerformancePoseMerge.md)
- [MKRFacePerformanceEvaluate](MKRFacePerformanceEvaluate.md)

## G-code

- [MKRGCodePrinterProfile](MKRGCodePrinterProfile.md)
- [MKRGCodeOrcaProfileLoader](MKRGCodeOrcaProfileLoader.md)
- [MKRGCodeLoadMeshModel](MKRGCodeLoadMeshModel.md)
- [MKRGCodeHeightmapPlate](MKRGCodeHeightmapPlate.md)
- [MKRGCodeSpiralVase](MKRGCodeSpiralVase.md)
- [MKRGCodePlanAnalyzer](MKRGCodePlanAnalyzer.md)
- [MKRGCodeBedMeshCompensate](MKRGCodeBedMeshCompensate.md)
- [MKRGCodeCalibrationTower](MKRGCodeCalibrationTower.md)
- [MKRGCodeConditionalInjector](MKRGCodeConditionalInjector.md)
- [MKRGCodePreview](MKRGCodePreview.md)
- [MKRGCodeExternalSlicer](MKRGCodeExternalSlicer.md)
- [MKRGCodeExport](MKRGCodeExport.md)

## Studio Review + Delivery

- [MKRStudioSlate](MKRStudioSlate.md)
- [MKRStudioReviewFrame](MKRStudioReviewFrame.md)
- [MKRStudioReviewBurnIn](MKRStudioReviewBurnIn.md)
- [MKRStudioCompareBoard](MKRStudioCompareBoard.md)
- [MKRStudioContactSheet](MKRStudioContactSheet.md)
- [MKRStudioSelectionSet](MKRStudioSelectionSet.md)
- [MKRStudioDeliveryPlan](MKRStudioDeliveryPlan.md)
- [MKRStudioReviewNotes](MKRStudioReviewNotes.md)
- [MKRStudioDeliverySheet](MKRStudioDeliverySheet.md)

## Publish Output

- [MKRPublishPromoFrame](MKRPublishPromoFrame.md)
- [MKRPublishEndCard](MKRPublishEndCard.md)
- [MKRPublishAssetManifest](MKRPublishAssetManifest.md)
- [MKRPublishManifestAtIndex](MKRPublishManifestAtIndex.md)
- [MKRPublishCopyDeck](MKRPublishCopyDeck.md)
- [MKRPublishCopyAtIndex](MKRPublishCopyAtIndex.md)
